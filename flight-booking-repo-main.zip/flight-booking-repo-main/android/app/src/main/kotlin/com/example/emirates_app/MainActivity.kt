package com.example.emirates_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
